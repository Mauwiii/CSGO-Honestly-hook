
# aristois-pasted-by-choZen   
##  thx too kuciak666 for [aristois](https://github.com/designer1337/aristois-legit)

project files for **aristois**,  "Counter-Strike: Global Offensive" cheat based on [alpha's sdk](https://github.com/alphauc/sdk).

## Changelog
+ completed skinlist						
+ added knifeanimation fix				// thx shonax paste
+ added glovechanger						// thx nskinz 
+ added nade pediction						// thx deadcell
+ added nade glow
+ added defuse esp
+ added flags is defusing, callout			// thx frosty v2
+ added removals fog						// thx antario paste
+ added better weapon esp with names/icons  // pasted from my old indigo that i released on pasters.cc 
+ added ambient light						// thx smefs indigo 
+ added weapon/hand/sleeve chams			// thx tonti spuri
+ added trigger/damage inticator			// thx tonti spuri
+ tested/added nullptr for bt chams
+ added speclist with OBS modes
+ changed visual loop dropped weapon names now with  if visible function
+ changed weapon esp  to a cleaner code 
+ added dropped weapon with icons 
+ changed weapon/hand/sleeve chams code
+ added check for bomb esp --> defused/exploded = bomb esp off
+ added menu so for woldesp is a switch for dropped weapon esp name/icon
+ added healthbased color chams
+ added dropped weapon es visible on key
+ added auto strafer

+ + please make/use new configs so it dosen´t crash etc on you

+ + for weapon icon esp you need font --> astriumwep.ttf


## FAQ
### Where's the DLL file?
You must build it yourself, after that you can localize dll in: **aristois-legit/output/debug/** folder. (**cheat.dll**)

### Where are config files stored?
Configs are stored in **C:\Users\YourUserName\Documents\aristois** folder.

### How can I open the menu?
Press `INSERT` key.

### How can I unload the cheat?
Press `END` key.

## Media
![image](https://imgur.com/X5vQfY2.png)
![image](https://imgur.com/Yhqxk4z.png)
![image](https://imgur.com/W3sz6rE.png)
![image](https://imgur.com/9b2oJM0.png)
![image](https://imgur.com/E8Je3D3.png)
  
my nickname is choZen on UC , Void and YouGame
