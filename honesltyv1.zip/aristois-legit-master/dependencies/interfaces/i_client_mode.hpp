#pragma once

class i_client_mode {
	// todo
};