#include "render.hpp"

c_render render;